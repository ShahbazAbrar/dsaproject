// CampaignManager.h
// Campaign management class coordinating campaigns and their tasks

#ifndef CAMPAIGNMANAGER_H
#define CAMPAIGNMANAGER_H

#include <QString>
#include <QVector>
#include <QDateTime>
#include "CampaignTasks.h"

// Structure representing a campaign
struct Campaign {
    int campaignId;
    QString name;
    QString brandName;
    double budget;
    QString influencerName;
    QDateTime createdDate;
    CampaignTasks* tasks;   // Linked list of tasks for this campaign
    bool isActive;
    
    // Constructor
    Campaign(int _id, QString _name, QString _brand, double _budget, QString _influencer = "")
        : campaignId(_id), name(_name), brandName(_brand), budget(_budget),
          influencerName(_influencer), createdDate(QDateTime::currentDateTime()),
          tasks(new CampaignTasks()), isActive(true) {}
    
    // Destructor
    ~Campaign() {
        delete tasks;
    }
};

// Campaign Manager class for creating and managing campaigns
class CampaignManager {
private:
    QVector<Campaign*> campaigns;
    int campaignIdCounter;
    
public:
    CampaignManager();
    ~CampaignManager();
    
    // Create a new campaign, returns campaign ID
    int createCampaign(QString name, QString brand, double budget, QString influencer = "");
    
    // Get campaign by ID
    Campaign* getCampaignById(int id);
    
    // Get all campaigns for a specific brand
    QVector<Campaign*> getCampaignsByBrand(QString brandName);
    
    // Get all campaigns assigned to a specific influencer
    QVector<Campaign*> getCampaignsByInfluencer(QString influencerName);
    
    // Assign an influencer to a campaign
    bool assignInfluencerToCampaign(int campaignId, QString influencerName);
    
    // Get all campaigns
    QVector<Campaign*> getAllCampaigns();
    
    // Get campaign count
    int getCampaignCount();
};

#endif // CAMPAIGNMANAGER_H
