#ifndef BRANDDASHBOARD_H
#define BRANDDASHBOARD_H

#include <QMainWindow>
#include <QComboBox>
#include <QLineEdit>
#include <QTextEdit>
#include <QListWidget>

// Forward declaration
class SystemManager;

class BrandDashboard : public QMainWindow
{
    Q_OBJECT

public:
    explicit BrandDashboard(QWidget *parent = nullptr);
    // Constructor with SystemManager for backend integration
    explicit BrandDashboard(SystemManager* manager, QWidget *parent = nullptr);

signals:
    void logoutClicked();

private slots:
    void handleSearch();
    void addCampaignTask();
    void handleCreateCampaign();
    void selectInfluencer(QListWidgetItem* item);

private:
    void setupUI();  // Common UI setup
    QWidget *createSearchInfluencersTab();
    QWidget *createCampaignCreationTab();
    QWidget *createCampaignHistoryTab();

    // Backend integration
    SystemManager* systemManager;
    int currentCampaignId;
    QString currentBrandName;

    // Search Tab
    QComboBox *nicheCombo;
    QLineEdit *followersField;
    QLineEdit *regionField;
    QListWidget *influencerResultsList;

    // Campaign Tab
    QLineEdit *selectedInfluencerField;
    QTextEdit *campaignDescription;
    QListWidget *taskListWidget;
    QLineEdit *newTaskField;
    QLineEdit *campaignNameField;
    QLineEdit *budgetField;

    // History Tab
    QListWidget *campaignHistoryList;
};

#endif // BRANDDASHBOARD_H

