// NotificationStack.cpp
// LIFO Stack implementation for notifications

#include "NotificationStack.h"

// Constructor - initialize with max size limit
NotificationStack::NotificationStack(int max) : maxSize(max) {
}

// Push a new notification onto the stack
// If at max capacity, removes oldest notification (bottom of stack)
void NotificationStack::push(QString message, QString category) {
    Notification notif(message, category);
    
    // If at maximum capacity, remove oldest (first element)
    if (items.size() >= maxSize) {
        items.removeFirst();
    }
    
    // Add new notification to top (end of vector for O(1) push_back)
    items.append(notif);
}

// Pop and return the top notification
Notification NotificationStack::pop() {
    if (items.isEmpty()) {
        return Notification();  // Return empty notification
    }
    
    // Remove and return last element (top of stack)
    Notification top = items.last();
    items.removeLast();
    return top;
}

// Peek at top notification without removing
Notification NotificationStack::peek() {
    if (items.isEmpty()) {
        return Notification();
    }
    
    return items.last();
}

// Get all notifications as formatted strings (most recent first)
QVector<QString> NotificationStack::getAllNotificationsAsStrings() {
    QVector<QString> results;
    
    // Iterate in reverse order (top to bottom)
    for (int i = items.size() - 1; i >= 0; i--) {
        const Notification& notif = items[i];
        
        // Format with category icon
        QString icon = "📢";
        if (notif.category == "REQUEST") icon = "📩";
        else if (notif.category == "TASK") icon = "✅";
        else if (notif.category == "CAMPAIGN") icon = "📋";
        
        QString readStatus = notif.isRead ? "" : " 🔴";
        QString notifStr = QString("%1 %2%3 (%4)")
                               .arg(icon)
                               .arg(notif.message)
                               .arg(readStatus)
                               .arg(notif.timestamp.toString("hh:mm"));
        results.append(notifStr);
    }
    
    return results;
}

// Get all notifications as objects (most recent first)
QVector<Notification> NotificationStack::getAllNotifications() {
    QVector<Notification> results;
    
    // Return in reverse order (top to bottom)
    for (int i = items.size() - 1; i >= 0; i--) {
        results.append(items[i]);
    }
    
    return results;
}

// Mark all notifications as read
void NotificationStack::markAllRead() {
    for (int i = 0; i < items.size(); i++) {
        items[i].isRead = true;
    }
}

// Clear all notifications
void NotificationStack::clear() {
    items.clear();
}

// Check if stack is empty
bool NotificationStack::isEmpty() {
    return items.isEmpty();
}

// Get current stack size
int NotificationStack::getSize() {
    return items.size();
}

// Count unread notifications
int NotificationStack::getUnreadCount() {
    int count = 0;
    for (const Notification& notif : items) {
        if (!notif.isRead) {
            count++;
        }
    }
    return count;
}
