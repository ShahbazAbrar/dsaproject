// CampaignTasks.cpp
// Singly Linked List implementation for campaign tasks

#include "CampaignTasks.h"

// Constructor - initialize empty list
CampaignTasks::CampaignTasks() : head(nullptr), taskCounter(0) {
}

// Destructor - free all nodes to prevent memory leaks
CampaignTasks::~CampaignTasks() {
    TaskNode* current = head;
    while (current != nullptr) {
        TaskNode* next = current->next;
        delete current;
        current = next;
    }
}

// Add a new task to the end of the linked list
// Time Complexity: O(n) where n is number of existing tasks
void CampaignTasks::addTask(QString description, QString deadline) {
    // Increment counter and create new task
    taskCounter++;
    TaskNode* newTask = new TaskNode(taskCounter, description, deadline);
    
    if (head == nullptr) {
        // List is empty - new task becomes head
        head = newTask;
    } else {
        // Traverse to end of list
        TaskNode* current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        // Append new task at the end
        current->next = newTask;
    }
}

// Mark a task as completed by its ID
// Returns true if task was found and marked, false otherwise
bool CampaignTasks::markComplete(int taskId) {
    TaskNode* current = head;
    
    // Search for task with matching ID
    while (current != nullptr) {
        if (current->taskId == taskId) {
            current->completed = true;
            return true;  // Task found and marked
        }
        current = current->next;
    }
    
    return false;  // Task not found
}

// Get all tasks formatted as strings for UI display
QVector<QString> CampaignTasks::getAllTasksAsStrings() {
    QVector<QString> results;
    TaskNode* current = head;
    
    while (current != nullptr) {
        // Format: status icon + description
        QString status = current->completed ? "✅" : "⬜";
        QString taskStr = QString("%1 [Task %2] %3")
                              .arg(status)
                              .arg(current->taskId)
                              .arg(current->description);
        
        // Add deadline if present
        if (!current->deadline.isEmpty()) {
            taskStr += QString(" (Due: %1)").arg(current->deadline);
        }
        
        results.append(taskStr);
        current = current->next;
    }
    
    return results;
}

// Count incomplete tasks
int CampaignTasks::getPendingCount() {
    int count = 0;
    TaskNode* current = head;
    
    while (current != nullptr) {
        if (!current->completed) {
            count++;
        }
        current = current->next;
    }
    
    return count;
}

// Count completed tasks
int CampaignTasks::getCompletedCount() {
    int count = 0;
    TaskNode* current = head;
    
    while (current != nullptr) {
        if (current->completed) {
            count++;
        }
        current = current->next;
    }
    
    return count;
}

// Check if list is empty
bool CampaignTasks::isEmpty() {
    return head == nullptr;
}

// Get total number of tasks
int CampaignTasks::getTaskCount() {
    int count = 0;
    TaskNode* current = head;
    
    while (current != nullptr) {
        count++;
        current = current->next;
    }
    
    return count;
}

// Find task by ID
TaskNode* CampaignTasks::getTaskById(int taskId) {
    TaskNode* current = head;
    
    while (current != nullptr) {
        if (current->taskId == taskId) {
            return current;
        }
        current = current->next;
    }
    
    return nullptr;  // Task not found
}
