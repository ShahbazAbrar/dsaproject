// mainwindow.cpp

#include "mainwindow.h"
#include "StartPage.h"
#include "BrandLoginPage.h"
#include "BrandDashboard.h"
#include <QApplication>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Collab Connect Application");
    resize(800, 600);

    // 1. Setup QStackedWidget (Page Manager)
    stackedWidget = new QStackedWidget(this);
    setCentralWidget(stackedWidget);

    // 2. Instantiate Pages
    startPage = new StartPage();
    brandLoginPage = new BrandLoginPage();
    brandDashboard = new BrandDashboard();

    // 3. Add Pages to the Stack
    stackedWidget->addWidget(startPage);      // Index 0: Start Page
    stackedWidget->addWidget(brandLoginPage);  // Index 1: Brand Login
    stackedWidget->addWidget(brandDashboard); // Index 2: Brand Dashboard

    // 4. Initial Navigation
    stackedWidget->setCurrentWidget(startPage);

    // 5. Connect Navigation Signals
    // Start Page -> Login Page
    connect(startPage, &StartPage::userTypeSelected, this, &MainWindow::navigateToLogin);

    // Login Page -> Dashboard
    connect(brandLoginPage, &BrandLoginPage::loginSuccess, this, &MainWindow::navigateToDashboard);

    // Login Page -> Start Page
    connect(brandLoginPage, &BrandLoginPage::backToStart, this, &MainWindow::navigateToStart);

    // Dashboard -> Start Page (Logout)
    connect(brandDashboard, &BrandDashboard::logoutClicked, this, &MainWindow::navigateToStart);
}

MainWindow::~MainWindow()
{
    // Destructor is implicitly handled by Qt's parent-child mechanism
}

void MainWindow::navigateToLogin(const QString &userType)
{
    if (userType == "Brand") {
        stackedWidget->setCurrentWidget(brandLoginPage);
    }
    // else if (userType == "Influencer") { // Logic for future Influencer UI
    //     qDebug() << "Navigate to Influencer Login";
    // }
}

void MainWindow::navigateToDashboard()
{
    stackedWidget->setCurrentWidget(brandDashboard);
}

void MainWindow::navigateToStart()
{
    stackedWidget->setCurrentWidget(startPage);
}
