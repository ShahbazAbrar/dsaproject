#ifndef BRANDLOGINPAGE_H
#define BRANDLOGINPAGE_H

#include <QWidget>

class QLineEdit;
class QPushButton;
class QLabel;
class QCheckBox;

class BrandLoginPage : public QWidget
{
    Q_OBJECT

public:
    explicit BrandLoginPage(QWidget *parent = nullptr);

signals:
    void loginSuccess();
    void backToStart();

private slots:
    void attemptLogin();
    void togglePasswordVisibility();

private:
    QLineEdit *emailField;
    QLineEdit *passwordField;
    QPushButton *loginButton;
    QPushButton *showPasswordButton;
    QLabel *errorLabel;
    QCheckBox *rememberMeCheckbox;
    bool passwordVisible;
};

#endif // BRANDLOGINPAGE_H
