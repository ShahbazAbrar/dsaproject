// main.cpp

#include "mainwindow.h"
#include <QApplication>

// --- DSA Structure Placeholders ---
// You will implement your Binary Search Tree (BST) and Linked List (LL)
// data structures and related logic here or in dedicated helper files.

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
