// RequestQueue.cpp
// FIFO Queue implementation for collaboration requests

#include "RequestQueue.h"

// Constructor - initialize empty queue
RequestQueue::RequestQueue() : front(nullptr), rear(nullptr), size(0), requestCounter(0) {
}

// Destructor - free all request nodes
RequestQueue::~RequestQueue() {
    while (front != nullptr) {
        RequestNode* temp = front;
        front = front->next;
        delete temp;
    }
}

// Add a new request to the rear of the queue
// Time Complexity: O(1) - constant time insertion at rear
void RequestQueue::enqueue(QString brand, QString campaign, QString influencer, int campaignId) {
    requestCounter++;
    RequestNode* newRequest = new RequestNode(requestCounter, brand, campaign, influencer, campaignId);
    
    if (rear == nullptr) {
        // Queue is empty - new node is both front and rear
        front = rear = newRequest;
    } else {
        // Add to rear and update rear pointer
        rear->next = newRequest;
        rear = newRequest;
    }
    
    size++;
}

// Remove and return the front request
// Returns nullptr if queue is empty
// IMPORTANT: Caller must delete the returned node to prevent memory leak
RequestNode* RequestQueue::dequeue() {
    if (front == nullptr) {
        return nullptr;  // Queue is empty
    }
    
    RequestNode* temp = front;
    front = front->next;
    
    // If queue becomes empty, update rear too
    if (front == nullptr) {
        rear = nullptr;
    }
    
    temp->next = nullptr;  // Disconnect from queue
    size--;
    
    return temp;
}

// View front request without removing
RequestNode* RequestQueue::peek() {
    return front;
}

// Get all requests formatted as strings for display
QVector<QString> RequestQueue::getAllRequestsAsStrings() {
    QVector<QString> results;
    RequestNode* current = front;
    
    while (current != nullptr) {
        QString reqStr = QString("📩 [Request #%1] %2 → %3 for campaign '%4' (%5)")
                             .arg(current->requestId)
                             .arg(current->brandName)
                             .arg(current->influencerName)
                             .arg(current->campaignName)
                             .arg(current->timestamp.toString("yyyy-MM-dd hh:mm"));
        results.append(reqStr);
        current = current->next;
    }
    
    return results;
}

// Check if queue is empty
bool RequestQueue::isEmpty() {
    return front == nullptr;
}

// Get current queue size
int RequestQueue::getSize() {
    return size;
}
