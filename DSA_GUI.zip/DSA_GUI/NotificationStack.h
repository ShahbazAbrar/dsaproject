// NotificationStack.h
// LIFO Stack for system notifications (most recent on top)

#ifndef NOTIFICATIONSTACK_H
#define NOTIFICATIONSTACK_H

#include <QString>
#include <QVector>
#include <QDateTime>

// Structure representing a notification
struct Notification {
    QString message;      // Notification text
    QDateTime timestamp;  // When notification was created
    QString category;     // Category: "REQUEST", "TASK", "CAMPAIGN", "SYSTEM"
    bool isRead;          // Whether notification has been viewed
    
    // Constructor
    Notification(QString _msg = "", QString _cat = "SYSTEM")
        : message(_msg), timestamp(QDateTime::currentDateTime()),
          category(_cat), isRead(false) {}
};

// LIFO Stack class for notification management
// Most recent notifications appear at the top
class NotificationStack {
private:
    QVector<Notification> items;  // Using QVector as backing store
    int maxSize;                  // Maximum number of notifications to keep
    
public:
    NotificationStack(int max = 100);
    
    // Push a new notification onto the stack
    // Time Complexity: O(1) amortized
    void push(QString message, QString category = "SYSTEM");
    
    // Pop and return the top notification
    // Returns empty Notification if stack is empty
    // Time Complexity: O(1)
    Notification pop();
    
    // View top notification without removing
    // Returns empty Notification if stack is empty
    // Time Complexity: O(1)
    Notification peek();
    
    // Get all notifications as formatted strings (top to bottom)
    QVector<QString> getAllNotificationsAsStrings();
    
    // Get all notifications as objects (top to bottom)
    QVector<Notification> getAllNotifications();
    
    // Mark all notifications as read
    void markAllRead();
    
    // Clear all notifications
    void clear();
    
    // Check if stack is empty
    bool isEmpty();
    
    // Get current number of notifications
    int getSize();
    
    // Get count of unread notifications
    int getUnreadCount();
};

#endif // NOTIFICATIONSTACK_H
