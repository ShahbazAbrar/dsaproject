// SystemManager.h
// Central coordinator for all DSA components

#ifndef SYSTEMMANAGER_H
#define SYSTEMMANAGER_H

#include <QString>
#include <QVector>
#include "InfluencerTree.h"
#include "CampaignManager.h"
#include "RequestQueue.h"
#include "NotificationStack.h"

// SystemManager - Central class coordinating all DSA data structures
// Provides unified API for frontend components
class SystemManager {
private:
    InfluencerTree* influencerTree;           // BST for influencer database
    CampaignManager* campaignManager;          // Campaign management
    RequestQueue* requestQueue;                // Queue for collaboration requests
    NotificationStack* brandNotifications;     // Stack for brand notifications
    NotificationStack* influencerNotifications; // Stack for influencer notifications
    
    // Load sample data for testing
    void loadSampleData();
    
public:
    SystemManager();
    ~SystemManager();
    
    // ==================== Influencer Operations ====================
    // Add a new influencer to the BST
    void addInfluencer(int id, QString name, QString niche, int followers, float engagement, QString email = "");
    
    // Search influencers by follower range and optional niche filter
    // If niche is "All" or empty, returns all in range
    QVector<Influencer*> searchInfluencers(int minFollowers, int maxFollowers, QString niche = "All");
    
    // Get all influencers sorted by followers
    QVector<Influencer*> getAllInfluencers();
    
    // Find influencer by ID
    Influencer* getInfluencerById(int id);
    
    // ==================== Campaign Operations ====================
    // Create a new campaign, returns campaign ID
    int createCampaign(QString name, QString brand, double budget);
    
    // Add a task to a campaign's linked list
    void addTaskToCampaign(int campaignId, QString taskDescription, QString deadline = "");
    
    // Mark a task as complete
    bool markTaskComplete(int campaignId, int taskId);
    
    // Get campaign by ID
    Campaign* getCampaign(int campaignId);
    
    // Get all campaigns for a brand
    QVector<Campaign*> getBrandCampaigns(QString brandName);
    
    // Get all campaigns for an influencer
    QVector<Campaign*> getInfluencerCampaigns(QString influencerName);
    
    // Get all campaigns
    QVector<Campaign*> getAllCampaigns();
    
    // ==================== Request Queue Operations ====================
    // Send a collaboration request (adds to queue)
    void sendCollaborationRequest(QString brand, QString campaign, QString influencer, int campaignId = 0);
    
    // Get the next request in queue (peek)
    RequestNode* getNextRequest();
    
    // Accept the front request (dequeues and assigns influencer)
    bool acceptRequest();
    
    // Reject the front request (dequeues without action)
    bool rejectRequest();
    
    // Get all pending requests as strings
    QVector<QString> getAllPendingRequests();
    
    // Get pending request count
    int getPendingRequestCount();
    
    // ==================== Notification Operations ====================
    // Add a notification for a specific user type
    void addNotification(QString message, QString userType, QString category = "SYSTEM");
    
    // Get all notifications for a user type as strings
    QVector<QString> getNotifications(QString userType);
    
    // Clear notifications for a user type
    void clearNotifications(QString userType);
    
    // Get unread notification count
    int getUnreadNotificationCount(QString userType);
    
    // Mark all notifications as read
    void markNotificationsRead(QString userType);
};

#endif // SYSTEMMANAGER_H
