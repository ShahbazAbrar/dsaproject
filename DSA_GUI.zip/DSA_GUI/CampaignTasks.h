// CampaignTasks.h
// Singly Linked List for managing sequential campaign tasks

#ifndef CAMPAIGNTASKS_H
#define CAMPAIGNTASKS_H

#include <QString>
#include <QVector>

// Linked List Node representing a campaign task
struct TaskNode {
    int taskId;           // Unique task identifier
    QString description;  // Task description text
    bool completed;       // Task completion status
    QString deadline;     // Optional deadline for task
    TaskNode* next;       // Pointer to next task in list
    
    // Constructor
    TaskNode(int _id, QString _desc, QString _deadline = "")
        : taskId(_id), description(_desc), completed(false),
          deadline(_deadline), next(nullptr) {}
};

// Singly Linked List class for campaign task management
// Maintains sequential order of tasks
class CampaignTasks {
private:
    TaskNode* head;       // Pointer to first task
    int taskCounter;      // Counter for generating unique task IDs
    
public:
    CampaignTasks();
    ~CampaignTasks();
    
    // Add a new task to the end of the list
    // Time Complexity: O(n) - must traverse to end
    void addTask(QString description, QString deadline = "");
    
    // Mark a specific task as completed by its ID
    // Time Complexity: O(n) - must search for task
    bool markComplete(int taskId);
    
    // Get all tasks as formatted strings for display
    // Format: "[✓/⬜] Task description"
    QVector<QString> getAllTasksAsStrings();
    
    // Count of incomplete (pending) tasks
    int getPendingCount();
    
    // Count of completed tasks
    int getCompletedCount();
    
    // Check if task list is empty
    bool isEmpty();
    
    // Get total number of tasks
    int getTaskCount();
    
    // Get task by ID
    TaskNode* getTaskById(int taskId);
};

#endif // CAMPAIGNTASKS_H
