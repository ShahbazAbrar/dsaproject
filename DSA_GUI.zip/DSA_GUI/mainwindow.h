// mainwindow.h

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>

class StartPage;
class BrandLoginPage;
class BrandDashboard;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void navigateToLogin(const QString &userType);
    void navigateToDashboard();
    void navigateToStart();

private:
    QStackedWidget *stackedWidget;
    StartPage *startPage;
    BrandLoginPage *brandLoginPage;
    BrandDashboard *brandDashboard;
};

#endif // MAINWINDOW_H
