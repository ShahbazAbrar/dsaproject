// StartPage.h

#ifndef STARTPAGE_H
#define STARTPAGE_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>

class StartPage : public QWidget
{
    Q_OBJECT

public:
    explicit StartPage(QWidget *parent = nullptr);

signals:
    void userTypeSelected(const QString &userType);

private slots:
    void onBrandClicked();

protected:
    // Required to draw the custom wave background
    void paintEvent(QPaintEvent *event) override;

private:
    // Removed setupAesthetics as it's now handled by paintEvent
    QLabel *brandingLabel;
    QPushButton *brandButton;
    QPushButton *influencerButton;
    QLabel *introLabel;
};

#endif // STARTPAGE_H
