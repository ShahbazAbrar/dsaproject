// InfluencerTree.cpp
// Binary Search Tree implementation for influencer database

#include "InfluencerTree.h"

// Constructor - initialize empty tree
InfluencerTree::InfluencerTree() : root(nullptr) {
}

// Destructor - clean up all allocated memory
InfluencerTree::~InfluencerTree() {
    destroyTree(root);
}

// Recursively delete all nodes in the tree (post-order traversal)
// This ensures children are deleted before their parent
void InfluencerTree::destroyTree(Influencer* node) {
    if (node != nullptr) {
        destroyTree(node->left);   // Delete left subtree
        destroyTree(node->right);  // Delete right subtree
        delete node;               // Delete current node
    }
}

// Public insert function - creates new influencer and inserts into BST
void InfluencerTree::insert(int id, QString name, QString niche, int followers,
                            float engagement, QString email) {
    Influencer* newInf = new Influencer(id, name, niche, followers, engagement, email);
    insertHelper(root, newInf);
}

// Private recursive insert helper
// BST property: left child has fewer followers, right child has more
void InfluencerTree::insertHelper(Influencer*& node, Influencer* newInf) {
    if (node == nullptr) {
        // Found insertion point - place the new node here
        node = newInf;
    } else if (newInf->followers < node->followers) {
        // New influencer has fewer followers - go left
        insertHelper(node->left, newInf);
    } else {
        // New influencer has more or equal followers - go right
        insertHelper(node->right, newInf);
    }
}

// Get all influencers sorted by follower count using inorder traversal
// Inorder traversal of BST gives sorted order
QVector<Influencer*> InfluencerTree::getAllInfluencers() {
    QVector<Influencer*> results;
    inorderHelper(root, results);
    return results;
}

// Private inorder traversal helper (Left -> Node -> Right)
void InfluencerTree::inorderHelper(Influencer* node, QVector<Influencer*>& results) {
    if (node != nullptr) {
        inorderHelper(node->left, results);    // Visit left subtree
        results.append(node);                   // Visit current node
        inorderHelper(node->right, results);   // Visit right subtree
    }
}

// Search for influencers within a follower count range [min, max]
// Uses BST properties to prune unnecessary branches
QVector<Influencer*> InfluencerTree::searchByRange(int min, int max) {
    QVector<Influencer*> results;
    searchRangeHelper(root, min, max, results);
    return results;
}

// Private range search helper with BST pruning
// Only visits branches that could contain valid results
void InfluencerTree::searchRangeHelper(Influencer* node, int min, int max,
                                        QVector<Influencer*>& results) {
    if (node == nullptr) {
        return;
    }
    
    // If current node's followers > min, left subtree might have valid results
    if (node->followers > min) {
        searchRangeHelper(node->left, min, max, results);
    }
    
    // If current node is within range, add to results
    if (node->followers >= min && node->followers <= max) {
        results.append(node);
    }
    
    // If current node's followers < max, right subtree might have valid results
    if (node->followers < max) {
        searchRangeHelper(node->right, min, max, results);
    }
}

// Search for influencers by niche category
// Must traverse entire tree since not sorted by niche
QVector<Influencer*> InfluencerTree::searchByNiche(QString niche) {
    QVector<Influencer*> allInfluencers = getAllInfluencers();
    QVector<Influencer*> results;
    
    for (Influencer* inf : allInfluencers) {
        // Case-insensitive comparison for flexibility
        if (inf->niche.compare(niche, Qt::CaseInsensitive) == 0) {
            results.append(inf);
        }
    }
    
    return results;
}

// Search for influencer by ID (linear search through tree)
Influencer* InfluencerTree::searchById(int id) {
    return searchByIdHelper(root, id);
}

// Private helper to search by ID using preorder traversal
Influencer* InfluencerTree::searchByIdHelper(Influencer* node, int id) {
    if (node == nullptr) {
        return nullptr;
    }
    
    if (node->id == id) {
        return node;
    }
    
    // Search in left subtree
    Influencer* found = searchByIdHelper(node->left, id);
    if (found != nullptr) {
        return found;
    }
    
    // Search in right subtree
    return searchByIdHelper(node->right, id);
}

// Check if tree is empty
bool InfluencerTree::isEmpty() {
    return root == nullptr;
}
