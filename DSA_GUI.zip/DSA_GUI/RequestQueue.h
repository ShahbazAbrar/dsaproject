// RequestQueue.h
// FIFO Queue for managing collaboration requests

#ifndef REQUESTQUEUE_H
#define REQUESTQUEUE_H

#include <QString>
#include <QVector>
#include <QDateTime>

// Queue Node representing a collaboration request
struct RequestNode {
    int requestId;            // Unique request ID
    QString brandName;        // Brand sending the request
    QString campaignName;     // Campaign associated with request
    QString influencerName;   // Target influencer
    int campaignId;           // Associated campaign ID
    QDateTime timestamp;      // When request was created
    RequestNode* next;        // Pointer to next request in queue
    
    // Constructor
    RequestNode(int _id, QString _brand, QString _campaign, QString _influencer, int _campId = 0)
        : requestId(_id), brandName(_brand), campaignName(_campaign),
          influencerName(_influencer), campaignId(_campId),
          timestamp(QDateTime::currentDateTime()), next(nullptr) {}
};

// FIFO Queue class for collaboration request management
// Requests are processed in first-in, first-out order
class RequestQueue {
private:
    RequestNode* front;   // Pointer to front of queue (for dequeue)
    RequestNode* rear;    // Pointer to rear of queue (for enqueue)
    int size;             // Current number of requests
    int requestCounter;   // Counter for generating unique request IDs
    
public:
    RequestQueue();
    ~RequestQueue();
    
    // Add a request to the rear of the queue
    // Time Complexity: O(1)
    void enqueue(QString brand, QString campaign, QString influencer, int campaignId = 0);
    
    // Remove and return the request at the front of the queue
    // Caller is responsible for deleting the returned node
    // Time Complexity: O(1)
    RequestNode* dequeue();
    
    // View the front request without removing it
    // Time Complexity: O(1)
    RequestNode* peek();
    
    // Get all requests as formatted strings for display
    QVector<QString> getAllRequestsAsStrings();
    
    // Check if queue is empty
    bool isEmpty();
    
    // Get current number of requests
    int getSize();
};

#endif // REQUESTQUEUE_H
