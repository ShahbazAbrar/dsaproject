// InfluencerTree.h
// Binary Search Tree for storing and searching influencers by follower count

#ifndef INFLUENCERTREE_H
#define INFLUENCERTREE_H

#include <QString>
#include <QVector>

// BST Node structure representing an influencer
struct Influencer {
    int id;
    QString name;
    QString niche;
    int followers;
    float engagementRate;
    QString email;
    Influencer* left;   // BST left child (smaller followers)
    Influencer* right;  // BST right child (larger followers)
    
    // Constructor for convenience
    Influencer(int _id, QString _name, QString _niche, int _followers, 
               float _engagement, QString _email = "")
        : id(_id), name(_name), niche(_niche), followers(_followers),
          engagementRate(_engagement), email(_email), left(nullptr), right(nullptr) {}
};

// Binary Search Tree class for influencer database
// Ordered by follower count for efficient range queries
class InfluencerTree {
private:
    Influencer* root;
    
    // Private helper functions for recursive BST operations
    void insertHelper(Influencer*& node, Influencer* newInf);
    void inorderHelper(Influencer* node, QVector<Influencer*>& results);
    void searchRangeHelper(Influencer* node, int min, int max, QVector<Influencer*>& results);
    void destroyTree(Influencer* node);
    Influencer* searchByIdHelper(Influencer* node, int id);
    
public:
    InfluencerTree();
    ~InfluencerTree();
    
    // Insert a new influencer into the BST (sorted by followers)
    // Time Complexity: O(log n) average, O(n) worst case
    void insert(int id, QString name, QString niche, int followers, 
                float engagement, QString email = "");
    
    // Search for influencers within a follower range
    // Uses BST properties for efficient pruning
    // Time Complexity: O(k + log n) where k = results found
    QVector<Influencer*> searchByRange(int min, int max);
    
    // Filter influencers by niche category
    // Requires full traversal since not sorted by niche
    // Time Complexity: O(n)
    QVector<Influencer*> searchByNiche(QString niche);
    
    // Get all influencers sorted by follower count (inorder traversal)
    // Time Complexity: O(n)
    QVector<Influencer*> getAllInfluencers();
    
    // Find specific influencer by ID
    // Time Complexity: O(n) since not sorted by ID
    Influencer* searchById(int id);
    
    // Check if tree is empty
    bool isEmpty();
};

#endif // INFLUENCERTREE_H
