// CampaignManager.cpp
// Campaign management implementation

#include "CampaignManager.h"

// Constructor - initialize empty manager
CampaignManager::CampaignManager() : campaignIdCounter(0) {
}

// Destructor - clean up all campaigns
CampaignManager::~CampaignManager() {
    for (Campaign* camp : campaigns) {
        delete camp;
    }
}

// Create a new campaign and return its ID
int CampaignManager::createCampaign(QString name, QString brand, double budget, QString influencer) {
    campaignIdCounter++;
    Campaign* newCampaign = new Campaign(campaignIdCounter, name, brand, budget, influencer);
    campaigns.append(newCampaign);
    return campaignIdCounter;
}

// Find campaign by ID
Campaign* CampaignManager::getCampaignById(int id) {
    for (Campaign* camp : campaigns) {
        if (camp->campaignId == id) {
            return camp;
        }
    }
    return nullptr;
}

// Get all campaigns for a specific brand
QVector<Campaign*> CampaignManager::getCampaignsByBrand(QString brandName) {
    QVector<Campaign*> results;
    for (Campaign* camp : campaigns) {
        if (camp->brandName.compare(brandName, Qt::CaseInsensitive) == 0) {
            results.append(camp);
        }
    }
    return results;
}

// Get all campaigns assigned to a specific influencer
QVector<Campaign*> CampaignManager::getCampaignsByInfluencer(QString influencerName) {
    QVector<Campaign*> results;
    for (Campaign* camp : campaigns) {
        if (camp->influencerName.compare(influencerName, Qt::CaseInsensitive) == 0) {
            results.append(camp);
        }
    }
    return results;
}

// Assign an influencer to a campaign
bool CampaignManager::assignInfluencerToCampaign(int campaignId, QString influencerName) {
    Campaign* camp = getCampaignById(campaignId);
    if (camp != nullptr) {
        camp->influencerName = influencerName;
        return true;
    }
    return false;
}

// Get all campaigns
QVector<Campaign*> CampaignManager::getAllCampaigns() {
    return campaigns;
}

// Get campaign count
int CampaignManager::getCampaignCount() {
    return campaigns.size();
}
