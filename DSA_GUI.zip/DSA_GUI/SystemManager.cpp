// SystemManager.cpp
// Central coordinator implementation with sample data

#include "SystemManager.h"

// Constructor - initialize all DSA components and load sample data
SystemManager::SystemManager() {
    influencerTree = new InfluencerTree();
    campaignManager = new CampaignManager();
    requestQueue = new RequestQueue();
    brandNotifications = new NotificationStack(100);
    influencerNotifications = new NotificationStack(100);
    
    // Load sample data for testing
    loadSampleData();
}

// Destructor - clean up all components
SystemManager::~SystemManager() {
    delete influencerTree;
    delete campaignManager;
    delete requestQueue;
    delete brandNotifications;
    delete influencerNotifications;
}

// Load sample data for testing purposes
void SystemManager::loadSampleData() {
    // ==================== Sample Influencers (BST) ====================
    // Varied follower counts from 50K to 200K across different niches
    addInfluencer(1, "Sarah Miller", "Beauty", 75000, 4.2f, "sarah@email.com");
    addInfluencer(2, "Mike Johnson", "Fitness", 120000, 5.1f, "mike@email.com");
    addInfluencer(3, "Emma Wilson", "Fashion", 95000, 3.8f, "emma@email.com");
    addInfluencer(4, "John Davis", "Tech", 50000, 6.5f, "john@email.com");
    addInfluencer(5, "Lisa Chen", "Food", 200000, 4.8f, "lisa@email.com");
    addInfluencer(6, "Alex Thompson", "Travel", 85000, 4.0f, "alex@email.com");
    addInfluencer(7, "Maya Patel", "Beauty", 110000, 5.5f, "maya@email.com");
    addInfluencer(8, "Chris Brown", "Gaming", 150000, 7.2f, "chris@email.com");
    addInfluencer(9, "Zara Ahmed", "Fashion", 180000, 4.5f, "zara@email.com");
    addInfluencer(10, "David Kim", "Fitness", 65000, 3.5f, "david@email.com");
    addInfluencer(11, "Sophie Lee", "Tech", 88000, 5.8f, "sophie@email.com");
    addInfluencer(12, "Ryan Garcia", "Gaming", 135000, 6.8f, "ryan@email.com");
    
    // ==================== Sample Collaboration Requests (Queue) ====================
    sendCollaborationRequest("Nike", "Summer Fitness Campaign", "Sarah Miller", 0);
    sendCollaborationRequest("Adidas", "New Collection Launch", "Mike Johnson", 0);
    sendCollaborationRequest("Puma", "Street Style Series", "Emma Wilson", 0);
    
    // ==================== Sample Notifications (Stack) ====================
    // Brand notifications
    addNotification("Welcome to Collab Connect!", "brand", "SYSTEM");
    addNotification("System ready - Start searching for influencers", "brand", "SYSTEM");
    addNotification("New feature: Advanced filtering now available", "brand", "SYSTEM");
    addNotification("Tip: Use the BST search for efficient influencer discovery", "brand", "SYSTEM");
    
    // Influencer notifications  
    addNotification("Welcome to Collab Connect!", "influencer", "SYSTEM");
    addNotification("System ready - View your collaboration requests", "influencer", "SYSTEM");
    addNotification("3 new collaboration requests waiting", "influencer", "REQUEST");
    addNotification("Tip: Complete tasks on time for better ratings", "influencer", "SYSTEM");
}

// ==================== Influencer Operations ====================

void SystemManager::addInfluencer(int id, QString name, QString niche, int followers, float engagement, QString email) {
    influencerTree->insert(id, name, niche, followers, engagement, email);
}

QVector<Influencer*> SystemManager::searchInfluencers(int minFollowers, int maxFollowers, QString niche) {
    // First get influencers in range using BST
    QVector<Influencer*> results = influencerTree->searchByRange(minFollowers, maxFollowers);
    
    // If niche filter is specified (not "All"), filter results
    if (!niche.isEmpty() && niche.compare("All", Qt::CaseInsensitive) != 0) {
        QVector<Influencer*> filtered;
        for (Influencer* inf : results) {
            if (inf->niche.compare(niche, Qt::CaseInsensitive) == 0) {
                filtered.append(inf);
            }
        }
        return filtered;
    }
    
    return results;
}

QVector<Influencer*> SystemManager::getAllInfluencers() {
    return influencerTree->getAllInfluencers();
}

Influencer* SystemManager::getInfluencerById(int id) {
    return influencerTree->searchById(id);
}

// ==================== Campaign Operations ====================

int SystemManager::createCampaign(QString name, QString brand, double budget) {
    return campaignManager->createCampaign(name, brand, budget);
}

void SystemManager::addTaskToCampaign(int campaignId, QString taskDescription, QString deadline) {
    Campaign* camp = campaignManager->getCampaignById(campaignId);
    if (camp != nullptr && camp->tasks != nullptr) {
        camp->tasks->addTask(taskDescription, deadline);
    }
}

bool SystemManager::markTaskComplete(int campaignId, int taskId) {
    Campaign* camp = campaignManager->getCampaignById(campaignId);
    if (camp != nullptr && camp->tasks != nullptr) {
        return camp->tasks->markComplete(taskId);
    }
    return false;
}

Campaign* SystemManager::getCampaign(int campaignId) {
    return campaignManager->getCampaignById(campaignId);
}

QVector<Campaign*> SystemManager::getBrandCampaigns(QString brandName) {
    return campaignManager->getCampaignsByBrand(brandName);
}

QVector<Campaign*> SystemManager::getInfluencerCampaigns(QString influencerName) {
    return campaignManager->getCampaignsByInfluencer(influencerName);
}

QVector<Campaign*> SystemManager::getAllCampaigns() {
    return campaignManager->getAllCampaigns();
}

// ==================== Request Queue Operations ====================

void SystemManager::sendCollaborationRequest(QString brand, QString campaign, QString influencer, int campaignId) {
    requestQueue->enqueue(brand, campaign, influencer, campaignId);
}

RequestNode* SystemManager::getNextRequest() {
    return requestQueue->peek();
}

bool SystemManager::acceptRequest() {
    RequestNode* req = requestQueue->dequeue();
    if (req != nullptr) {
        // If request has a campaign ID, assign the influencer
        if (req->campaignId > 0) {
            campaignManager->assignInfluencerToCampaign(req->campaignId, req->influencerName);
        }
        
        // Add notification
        QString msg = QString("Request accepted: %1 for '%2'")
                          .arg(req->influencerName)
                          .arg(req->campaignName);
        addNotification(msg, "brand", "REQUEST");
        addNotification(msg, "influencer", "REQUEST");
        
        delete req;  // Clean up the dequeued request
        return true;
    }
    return false;
}

bool SystemManager::rejectRequest() {
    RequestNode* req = requestQueue->dequeue();
    if (req != nullptr) {
        // Add notification
        QString msg = QString("Request declined: %1 for '%2'")
                          .arg(req->influencerName)
                          .arg(req->campaignName);
        addNotification(msg, "brand", "REQUEST");
        addNotification(msg, "influencer", "REQUEST");
        
        delete req;  // Clean up the dequeued request
        return true;
    }
    return false;
}

QVector<QString> SystemManager::getAllPendingRequests() {
    return requestQueue->getAllRequestsAsStrings();
}

int SystemManager::getPendingRequestCount() {
    return requestQueue->getSize();
}

// ==================== Notification Operations ====================

void SystemManager::addNotification(QString message, QString userType, QString category) {
    if (userType.compare("brand", Qt::CaseInsensitive) == 0) {
        brandNotifications->push(message, category);
    } else if (userType.compare("influencer", Qt::CaseInsensitive) == 0) {
        influencerNotifications->push(message, category);
    }
}

QVector<QString> SystemManager::getNotifications(QString userType) {
    if (userType.compare("brand", Qt::CaseInsensitive) == 0) {
        return brandNotifications->getAllNotificationsAsStrings();
    } else if (userType.compare("influencer", Qt::CaseInsensitive) == 0) {
        return influencerNotifications->getAllNotificationsAsStrings();
    }
    return QVector<QString>();
}

void SystemManager::clearNotifications(QString userType) {
    if (userType.compare("brand", Qt::CaseInsensitive) == 0) {
        brandNotifications->clear();
    } else if (userType.compare("influencer", Qt::CaseInsensitive) == 0) {
        influencerNotifications->clear();
    }
}

int SystemManager::getUnreadNotificationCount(QString userType) {
    if (userType.compare("brand", Qt::CaseInsensitive) == 0) {
        return brandNotifications->getUnreadCount();
    } else if (userType.compare("influencer", Qt::CaseInsensitive) == 0) {
        return influencerNotifications->getUnreadCount();
    }
    return 0;
}

void SystemManager::markNotificationsRead(QString userType) {
    if (userType.compare("brand", Qt::CaseInsensitive) == 0) {
        brandNotifications->markAllRead();
    } else if (userType.compare("influencer", Qt::CaseInsensitive) == 0) {
        influencerNotifications->markAllRead();
    }
}
